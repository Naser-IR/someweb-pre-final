import i from './zoro.jpeg'
var User = [{Name:'zor',pass:'Zoro5',useName:'roronoa',img:i}];
export default User;