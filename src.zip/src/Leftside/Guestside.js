

import React from "react";


// import Type from './Type';

function Guest({chexk,name, message, time, img, id }) {
  const open = function () {
    chexk({name,img,message,id});
    //console.log({ name });
  };
  return (
    <div id="guestrow" onClick={open} className="chat-list-item d-flex flex-row w-100 p-2 border-bottom" type="button">
      <div id="r" className="row bg-black">
        <div id="imgc" className="col-4">
          <img className="rounded-circle" alt="" src={img}></img>
        </div>
        <div id="s" className="col -8">
          <div id="nrow" className="row d-flex">
            {" "}
            <span style={{color:"white"}} id="cur" className=" d-flex">  {name}{" "}</span>
            {" "}<span style={{color:"white"}}>{time}</span> {" "}
          </div>
          <div style={{color:"white"}} id="mrow" className="row">
            {" "}
            {message}
          </div>
        </div>
      </div>
    </div>
  );
}
export default Guest;
