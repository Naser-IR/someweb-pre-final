


function Handle({s}){

    return(
        <div>
        <p className="chat-message" style={{color:"white"}} id='fm' >  {s} </p>
        </div>
    );
   
}
export default Handle;